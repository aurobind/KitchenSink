//{
		//  "aaData":[
		//	["1","0","09/13/2016 22:00","10:00","0", "Create Touch Files","PROD","DB2 DBA","Aurobind"],
		//	["2","1","09/13/2016 23:00","20:00","0", "Deploy Files","MIS","DB2 DBA","Prafulla"],
		//	["3","1","09/13/2016 22:10","20:00","1", "Deploy Files","PROD","DB2 DBA","Varshith"]
		//  ],
		//  "aoColumnDefs":[{
		//		"aTargets":[ 2 ]
		//	  , "sType": "date"
		//	  , "mRender": function(date, type) {
		//		  //rowCount= fnGetData().length - 1;
		//		  return new Date(date).toDateString();
		//	  }  
		//  }]
		//}
		
		
	var date = "09/13/2016 22:00:00"
			var releaseDate = Date.parse(date).add(10).minutes();
			document.write(releaseDate);
				document.write(planTable.fnGetData().length);
				
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>